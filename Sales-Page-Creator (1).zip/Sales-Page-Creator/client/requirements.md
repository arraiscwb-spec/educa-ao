## Packages
framer-motion | Smooth scroll animations and entrance effects for a premium feel
lucide-react | Beautiful icons for features and benefits
clsx | Utility for conditional class names
tailwind-merge | Utility for merging tailwind classes

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  sans: ["'DM Sans'", "sans-serif"],
  display: ["'Outfit'", "sans-serif"],
  handwriting: ["'Architects Daughter'", "cursive"],
}
