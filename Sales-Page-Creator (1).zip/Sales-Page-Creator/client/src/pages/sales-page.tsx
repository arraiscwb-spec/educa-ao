import { 
  CheckCircle2, 
  XCircle, 
  Heart, 
  Clock, 
  FileText, 
  Download, 
  ShieldCheck, 
  Star, 
  Users, 
  Zap, 
  BookOpen,
  ArrowDown,
  Play,
  ShoppingBag,
  MessageCircle,
  Puzzle,
  Compass,
  Sun
} from "lucide-react";
import { motion } from "framer-motion";
import { ButtonCTA } from "@/components/ui/button-cta";
import { FeatureCard } from "@/components/feature-card";
import { TestimonialCard } from "@/components/testimonial-card";
import { PricingCard } from "@/components/pricing-card";

// Animation variants
const fadeIn = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.6 } }
};

const staggerContainer = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.2
    }
  }
};

export default function SalesPage() {
  const scrollToCheckout = () => {
    document.getElementById("offer")?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <div className="min-h-screen font-sans overflow-x-hidden bg-white">
      
      {/* 1. HERO SECTION */}
      <section className="relative pt-10 pb-20 lg:pt-20 lg:pb-32 overflow-hidden bg-[#f8fcf9]">
        <div className="container mx-auto px-4 text-center max-w-5xl relative z-10">
          <motion.div 
            initial="hidden"
            animate="visible"
            variants={staggerContainer}
            className="space-y-6"
          >
            <motion.h1 variants={fadeIn} className="text-4xl md:text-6xl lg:text-8xl font-display font-black leading-[1.05] text-primary uppercase drop-shadow-sm">
              PROFESSORA, O SEU ANO LETIVO DE 2026 INTEIRO JÁ ESTÁ PRONTO!
            </motion.h1>

            <motion.p variants={fadeIn} className="text-2xl md:text-3xl text-foreground leading-relaxed max-w-4xl mx-auto font-bold italic text-primary/80">
              "Imagine nunca mais levar trabalho para casa..."
            </motion.p>

            <motion.p variants={fadeIn} className="text-xl md:text-2xl text-foreground/80 leading-relaxed max-w-4xl mx-auto font-medium">
              Pare de sacrificar suas noites e finais de semana. Tenha acesso imediato ao maior banco de materiais do Brasil: <span className="bg-secondary px-2 py-1 rounded font-black text-secondary-foreground shadow-sm">1.500 Planos de Aulas 100% alinhados à BNCC</span> + Inclusão.
            </motion.p>

            <motion.div variants={fadeIn} className="relative inline-block w-full max-w-3xl rounded-3xl overflow-hidden shadow-2xl border-4 border-white mb-10">
               <img 
                 src="https://i.ibb.co/6R1BzVMQ/imagem-2026-01-09-231317674.png" 
                 alt="Materiais Educativos 2026" 
                 className="w-full h-auto object-cover"
               />
            </motion.div>

            <motion.div variants={fadeIn} className="pt-4">
              <ButtonCTA onClick={scrollToCheckout} size="xl" className="w-full md:w-auto bg-secondary hover:bg-secondary/90 text-secondary-foreground text-2xl py-8 px-12 rounded-2xl shadow-[0_10px_0_0_#d49a00] active:translate-y-1 active:shadow-none transition-all font-black uppercase">
                QUERO GARANTIR MEU ANO LETIVO AGORA! ➜
              </ButtonCTA>
              <div className="mt-6 flex flex-wrap justify-center gap-4 text-sm font-bold text-muted-foreground uppercase">
                <span className="flex items-center gap-1">
                  <ShieldCheck className="w-5 h-5 text-green-600" /> Compra Segura
                </span>
                <span className="flex items-center gap-1">
                  <Zap className="w-5 h-5 text-secondary" /> Acesso Imediato
                </span>
              </div>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* 2. IDENTIFICAÇÃO COM A DOR */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4 max-w-4xl">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-5xl font-black mb-6 text-primary">
              Você ama a sala de aula, ama as crianças... mas a burocracia está te consumindo, certo?
            </h2>
            <p className="text-xl text-muted-foreground">Eu sei exatamente como é a sua rotina:</p>
          </div>

          <div className="bg-primary/5 p-8 md:p-12 rounded-[3rem] border-2 border-primary/10">
            <div className="space-y-8">
              {[
                { title: "Cansaço Extremo", text: "Chegar em casa **exausta** e ainda ter que ligar o computador para digitar planos." },
                { title: "Domingos Perdidos", text: "Passar o domingo à tarde **caçando códigos na BNCC** em vez de descansar com sua família." },
                { title: "Ansiedade Constante", text: "Aquela **ansiedade de domingo à noite** porque a semana vai começar e o planejamento não está pronto." },
                { title: "Solidão Pedagógica", text: "Se sentir **perdida e sem apoio** na hora de criar atividades e planejamentos." }
              ].map((item, idx) => (
                <motion.div 
                  key={idx}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  className="flex items-start gap-6"
                >
                  <XCircle className="w-10 h-10 text-red-500 flex-shrink-0 mt-1" />
                  <div>
                    <h3 className="text-2xl font-black text-primary uppercase mb-1">{item.title}</h3>
                    <p className="text-xl leading-snug" dangerouslySetInnerHTML={{ __html: item.text.replace(/\*\*(.*?)\*\*/g, '<span class="font-black text-primary">$1</span>') }} />
                  </div>
                </motion.div>
              ))}
            </div>
          </div>

          <div className="mt-16 text-center space-y-8">
             <p className="text-3xl font-bold text-foreground/90 leading-tight">Você não estudou para virar uma "digitadora de planejamentos".</p>
             <div className="bg-primary py-6 px-4 rounded-3xl shadow-xl transform -rotate-1">
               <p className="text-3xl md:text-5xl font-black text-white uppercase leading-none">Você estudou para ENSINAR, <br className="hidden md:block"/> BRINCAR E TRANSFORMAR VIDAS.</p>
             </div>
             <p className="text-2xl text-handwriting text-primary font-bold animate-bounce mt-8">E se você pudesse resolver a parte chata e burocrática com um único clique? 👇</p>
          </div>
        </div>
      </section>

      {/* 4. APRESENTAÇÃO DO PRODUTO */}
      <section className="py-20 bg-primary text-white text-center">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl md:text-6xl font-black mb-8 uppercase leading-tight">
            APRESENTAMOS O <br/> KIT PERFEITO PARA A EDUCAÇÃO INFANTIL 2026
          </h2>
          <p className="text-xl md:text-2xl mb-16 opacity-90 max-w-3xl mx-auto">
            Não são atividades soltas. É um **Sistema Completo de Planejamento**, organizado passo a passo, de janeiro a dezembro.
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-6 max-w-7xl mx-auto">
            {[
              { icon: "👶", title: "Berçário", desc: "Estimulação sensorial, motora e cuidados essenciais." },
              { icon: "🧸", title: "Maternal 1", desc: "Oralidade, exploração e primeiros passos na socialização." },
              { icon: "🎨", title: "Maternal 2", desc: "Identidade, autonomia e desenvolvimento coordenação." },
              { icon: "✏️", title: "Pré-Escola 1", desc: "Introdução lúdica a letras, números e formas." },
              { icon: "🏫", title: "Pré-Escola 2", desc: "Preparação para a alfabetização e letramento." }
            ].map((item, idx) => (
              <div key={idx} className="bg-white/10 backdrop-blur-sm p-8 rounded-3xl border border-white/20">
                <div className="text-5xl mb-4">{item.icon}</div>
                <h3 className="text-2xl font-black mb-3 uppercase">{item.title}</h3>
                <p className="text-white/80">{item.desc}</p>
              </div>
            ))}
          </div>

          <div className="mt-20 max-w-4xl mx-auto space-y-6">
            <h3 className="text-3xl font-bold mb-8">✅ Tudo Pronto Para Usar:</h3>
            <div className="space-y-4 text-left">
               <div className="flex items-start gap-4 text-xl">
                 <CheckCircle2 className="w-8 h-8 text-secondary flex-shrink-0" />
                 <p><strong>100% Alinhado à BNCC 2026:</strong> Códigos, campos de experiência e objetivos já organizados.</p>
               </div>
               <div className="flex items-start gap-4 text-xl">
                 <CheckCircle2 className="w-8 h-8 text-secondary flex-shrink-0" />
                 <p><strong>Arquivos Editáveis (Word):</strong> Mude o que quiser, coloque seu nome, adapte para sua escola.</p>
               </div>
               <div className="flex items-start gap-4 text-xl">
                 <CheckCircle2 className="w-8 h-8 text-secondary flex-shrink-0" />
                 <p><strong>Arquivos em PDF:</strong> Prontos para imprimir na hora da pressa.</p>
               </div>
            </div>
            <div className="pt-12">
               <ButtonCTA onClick={scrollToCheckout} size="xl" className="bg-secondary text-secondary-foreground text-2xl py-8 px-12 rounded-2xl shadow-[0_10px_0_0_#d49a00] uppercase font-black">
                 QUERO GARANTIR O MEU ANO LETIVO AGORA!
               </ButtonCTA>
            </div>
          </div>
        </div>
      </section>

      {/* 7. PROVA SOCIAL */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4 max-w-5xl text-center">
          <h2 className="text-3xl md:text-5xl font-black mb-4 text-primary uppercase">
            Não acredite apenas na minha palavra...
          </h2>
          <p className="text-2xl mb-16 text-muted-foreground">Veja o que quem já baixou está dizendo:</p>
          
          <div className="grid md:grid-cols-3 gap-8">
            <TestimonialCard 
              name="Ana Paula Silva" 
              role="Professora de Educação Infantil" 
              avatarInitial="A"
              content="Estou apaixonada por esse material! O tempo que eu perdia no domingo agora eu uso com meus filhos. Tudo muito organizado e lindo."
            />
            <TestimonialCard 
              name="Juliana Oliveira" 
              role="Professora Maternal 1" 
              avatarInitial="J"
              content="O melhor investimento que fiz esse ano. Os planos são completos e fáceis de adaptar. Meus alunos estão amando as novas atividades!"
            />
            <TestimonialCard 
              name="Beatriz Santos" 
              role="Coordenadora Pedagógica" 
              avatarInitial="B"
              content="Recomendei para todas as professoras da minha escola. Alinhamento perfeito com a BNCC e facilita muito a nossa rotina diária."
            />
          </div>
          <p className="mt-12 text-muted-foreground font-bold">← Arraste para o lado para ver mais →</p>
        </div>
      </section>

      {/* 9. COMO FUNCIONA */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4 max-w-5xl">
          <h2 className="text-3xl md:text-5xl font-black text-center mb-16 text-primary uppercase">Como funciona o acesso?</h2>
          
          <div className="grid md:grid-cols-3 gap-12 text-center">
            {[
              { icon: "📧", title: "Receba no E-mail", desc: "Assim que a compra for confirmada, você recebe um e-mail com login e senha. É imediato!" },
              { icon: "📥", title: "Baixe Tudo", desc: "Acesse nossa área de membros e faça o download dos arquivos em PDF e Word." },
              { icon: "🖨️", title: "Edite ou Imprima", desc: "Abra no Word para editar o que quiser ou imprima o PDF direto para usar." }
            ].map((item, i) => (
              <div key={i} className="relative group">
                <div className="text-6xl mb-6 bg-white w-24 h-24 rounded-full flex items-center justify-center mx-auto shadow-lg group-hover:scale-110 transition-transform">
                  {item.icon}
                </div>
                <div className="absolute top-0 right-1/4 w-8 h-8 bg-primary text-white rounded-full flex items-center justify-center font-black">
                  {i+1}
                </div>
                <h3 className="text-2xl font-black mb-4 uppercase">{item.title}</h3>
                <p className="text-lg text-muted-foreground">{item.desc}</p>
              </div>
            ))}
          </div>
          <div className="mt-16 text-center">
             <p className="text-2xl font-bold text-primary flex items-center justify-center gap-2">
               <ShieldCheck className="w-8 h-8" /> Acesso Vitalício: O material é seu para sempre.
             </p>
          </div>
        </div>
      </section>

      {/* 10. PARA QUEM É */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4 max-w-5xl">
          <h2 className="text-4xl md:text-6xl font-black text-center mb-20 text-primary uppercase">PARA QUEM É ESSE MATERIAL?</h2>
          
          <div className="grid md:grid-cols-2 gap-8">
            {[
              { icon: <Sun className="w-12 h-12 text-secondary" />, text: "Para quem quer ter **finais de semana livres** para curtir a família sem culpa." },
              { icon: <Compass className="w-12 h-12 text-secondary" />, text: "Para quem **assumiu turmas novas** e precisa de um norte pedagógico seguro." },
              { icon: <Puzzle className="w-12 h-12 text-secondary" />, text: "Para quem se sente insegura ou perdida com a **Educação Inclusiva**." },
              { icon: <Clock className="w-12 h-12 text-secondary" />, text: "Para **professoras experientes** que querem apenas otimizar seu tempo precioso." }
            ].map((item, idx) => (
              <div key={idx} className="flex items-center gap-6 p-8 rounded-[2.5rem] bg-[#f8fcf9] border-2 border-primary/5">
                <div className="bg-white p-4 rounded-3xl shadow-sm flex-shrink-0">
                  {item.icon}
                </div>
                <p className="text-xl" dangerouslySetInnerHTML={{ __html: item.text.replace(/\*\*(.*?)\*\*/g, '<span class="font-black text-primary">$1</span>') }} />
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 14. OFERTA FINAL & 12. GARANTIA */}
      <section id="offer" className="py-24 bg-[#f8fcf9] relative">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl md:text-7xl font-black text-center mb-20 text-primary uppercase leading-tight">
            Escolha a Melhor Oferta <br className="hidden md:block"/> para Você 🎁
          </h2>
          <PricingCard />

          {/* Guarantee */}
          <div className="max-w-3xl mx-auto mt-20 flex flex-col md:flex-row items-center gap-8 bg-white p-10 rounded-[3rem] border-4 border-dashed border-primary/20 shadow-xl">
            <div className="flex-shrink-0">
               <div className="w-24 h-24 bg-primary/10 rounded-full flex items-center justify-center border-4 border-primary">
                 <ShieldCheck className="w-12 h-12 text-primary" />
               </div>
            </div>
            <div className="text-center md:text-left">
              <h3 className="text-3xl font-black mb-3 text-primary uppercase">Garantia Incondicional de 7 Dias</h3>
              <p className="text-xl text-muted-foreground font-medium">
                Baixe o material agora. Se em até 7 dias você achar que não valeu a pena, basta enviar um e-mail e devolvemos 100% do seu dinheiro. Sem burocracia.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* 13. FAQ */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4 max-w-3xl">
          <h2 className="text-4xl md:text-6xl font-black text-center mb-16 text-primary uppercase">Dúvidas Frequentes</h2>
          <div className="space-y-6">
            {[
              { q: "O material está 100% atualizado para 2026?", a: "Com certeza! Todos os 1.500 planos foram revisados e estão alinhados com as diretrizes mais recentes da BNCC." },
              { q: "Como recebo o acesso aos arquivos?", a: "É imediato seu acesso. Assim que seu pagamento for confirmado, você recebe o material completo + 2 bônus no seu e-mail." },
              { q: "Os arquivos são editáveis?", a: "Sim! Você recebe os arquivos em dois formatos: PDF (imprimir rápido) e Word (totalmente editável)." },
              { q: "Serve para quais turmas exatas?", a: "O Kit cobre toda a Educação Infantil: Berçário, Maternal 1, Maternal 2, Pré-Escola 1 e Pré-Escola 2." },
              { q: "O acesso expira?", a: "Não! O acesso é VITALÍCIO. Uma vez comprado, o material é seu para sempre." }
            ].map((item, i) => (
              <div key={i} className="border-b-2 border-gray-100 pb-6">
                <h4 className="font-black text-2xl mb-4 text-primary uppercase leading-tight">{item.q}</h4>
                <p className="text-xl text-muted-foreground">{item.a}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <footer className="bg-primary text-white py-20 text-center">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-5xl font-black mb-8 uppercase">Não deixe para depois o sossego que você pode garantir hoje.</h2>
          <p className="opacity-60">&copy; 2025 Todos os direitos reservados. Material Educacional Exclusivo.</p>
        </div>
      </footer>
      
      {/* Sticky Mobile CTA */}
      <div className="md:hidden fixed bottom-0 left-0 w-full p-4 bg-white/90 backdrop-blur-xl border-t-2 border-primary/10 z-50">
        <a href="https://checkout.salmoscomentados.online/VCCL1O8SCOW5" target="_blank" rel="noopener noreferrer" className="block w-full">
          <ButtonCTA className="w-full bg-secondary text-secondary-foreground font-black uppercase py-5 text-lg shadow-[0_4px_0_0_#d49a00] active:translate-y-1 active:shadow-none">
            GARANTIR MINHA VAGA AGORA!
          </ButtonCTA>
        </a>
      </div>
    </div>
  );
}
