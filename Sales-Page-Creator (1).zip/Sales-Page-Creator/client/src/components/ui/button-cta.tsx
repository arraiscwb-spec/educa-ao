import { cn } from "@/lib/utils";
import { ArrowRight, Sparkles } from "lucide-react";
import { ButtonHTMLAttributes, forwardRef } from "react";

interface ButtonCTAProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: "primary" | "secondary" | "outline";
  size?: "default" | "lg" | "xl";
  showIcon?: boolean;
}

export const ButtonCTA = forwardRef<HTMLButtonElement, ButtonCTAProps>(
  ({ className, variant = "primary", size = "lg", showIcon = true, children, ...props }, ref) => {
    
    const variants = {
      primary: "bg-primary text-primary-foreground shadow-xl shadow-primary/30 hover:shadow-2xl hover:shadow-primary/40 hover:-translate-y-1 border-b-4 border-primary-foreground/20 active:border-b-0 active:translate-y-0",
      secondary: "bg-secondary text-secondary-foreground shadow-lg shadow-secondary/30 hover:shadow-xl hover:shadow-secondary/40 hover:-translate-y-1 border-b-4 border-secondary-foreground/20 active:border-b-0 active:translate-y-0",
      outline: "bg-white text-primary border-2 border-primary/20 hover:bg-primary/5 hover:border-primary/50 shadow-sm hover:shadow-md"
    };

    const sizes = {
      default: "px-6 py-3 text-base rounded-xl",
      lg: "px-8 py-4 text-lg md:text-xl font-bold rounded-2xl",
      xl: "px-10 py-5 text-xl md:text-2xl font-black tracking-wide rounded-2xl w-full md:w-auto"
    };

    return (
      <button
        ref={ref}
        className={cn(
          "relative inline-flex items-center justify-center transition-all duration-300 ease-out disabled:opacity-50 disabled:pointer-events-none gap-3 group overflow-hidden isolate",
          variants[variant],
          sizes[size],
          className
        )}
        {...props}
      >
        {/* Shimmer effect */}
        {variant !== "outline" && (
          <div className="absolute inset-0 -z-10 bg-[linear-gradient(45deg,transparent_25%,rgba(255,255,255,0.3)_50%,transparent_75%)] w-[200%] h-full animate-[shimmer_3s_infinite] translate-x-[-100%]" />
        )}
        
        <span className="relative z-10 flex items-center gap-2">
          {children}
          {showIcon && (
            <ArrowRight className="w-5 h-5 md:w-6 md:h-6 transition-transform group-hover:translate-x-1" />
          )}
        </span>
      </button>
    );
  }
);

ButtonCTA.displayName = "ButtonCTA";
