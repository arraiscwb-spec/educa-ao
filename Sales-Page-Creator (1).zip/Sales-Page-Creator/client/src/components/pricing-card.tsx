import { Check, ShieldCheck, Zap, Users } from "lucide-react";
import { ButtonCTA } from "./ui/button-cta";
import { cn } from "@/lib/utils";

interface PricingOfferProps {
  title: string;
  price: string;
  originalPrice: string;
  features: string[];
  buttonText: string;
  checkoutUrl: string;
  isPremium?: boolean;
  highlight?: string;
  subText?: string;
}

function OfferCard({ 
  title, 
  price, 
  originalPrice, 
  features, 
  buttonText, 
  checkoutUrl,
  isPremium, 
  highlight, 
  subText 
}: PricingOfferProps) {
  return (
    <div className={cn(
      "flex-1 flex flex-col bg-white rounded-[2.5rem] p-8 md:p-10 shadow-2xl relative overflow-hidden border-4",
      isPremium ? "border-primary scale-105 z-10" : "border-primary/10"
    )}>
      {highlight && (
        <div className="absolute top-0 right-0 bg-secondary text-secondary-foreground text-xs font-black px-6 py-2 rounded-bl-2xl uppercase tracking-widest shadow-lg">
          {highlight}
        </div>
      )}

      <div className="text-center mb-8">
        <h3 className="text-2xl font-black text-primary uppercase mb-4 leading-tight">{title}</h3>
        <p className="text-muted-foreground line-through text-lg font-medium mb-1">
          De R$ {originalPrice} por apenas
        </p>
        <div className="flex items-center justify-center gap-1 text-primary">
          <span className="text-2xl font-black self-start mt-2">R$</span>
          <span className="text-7xl font-black tracking-tighter leading-none">{price}</span>
        </div>
      </div>

      <div className="space-y-4 mb-8 flex-1">
        {features.map((feature, idx) => (
          <div key={idx} className="flex items-start gap-3">
            <div className="mt-1 bg-green-100 rounded-full p-0.5 flex-shrink-0">
              <Check className="w-4 h-4 text-green-600" />
            </div>
            <span className="text-lg font-medium leading-tight text-left">{feature}</span>
          </div>
        ))}
      </div>

      <div className="space-y-4 text-center">
        <a href={checkoutUrl} target="_blank" rel="noopener noreferrer" className="block w-full">
          <ButtonCTA 
            variant={isPremium ? "secondary" : "primary"}
            className={cn(
              "w-full py-8 text-2xl shadow-[0_8px_0_0_rgba(0,0,0,0.1)]",
              isPremium && "shadow-[0_8px_0_0_#d49a00]"
            )}
          >
            {buttonText}
          </ButtonCTA>
        </a>
        
        {subText ? (
           <p className="text-primary font-black flex items-center justify-center gap-2">
             <Users className="w-5 h-5" /> {subText}
           </p>
        ) : (
          <p className="text-sm font-bold text-muted-foreground flex items-center justify-center gap-2 uppercase">
            <ShieldCheck className="w-4 h-4" /> Pagamento Único • Vitalício
          </p>
        )}
      </div>
    </div>
  );
}

export function PricingCard() {
  return (
    <div className="max-w-6xl mx-auto flex flex-col lg:flex-row gap-8 lg:gap-4 items-stretch px-4 py-12">
      <OfferCard 
        title="Kit Essencial"
        price="10,00"
        originalPrice="247,00"
        checkoutUrl="https://checkout.salmoscomentados.online/VCCL1O8SCOW4"
        features={[
          "1.500 Planos Prontos – Educação Infantil 2026",
          "Acesso imediato no seu e-mail",
          "Garantia Incondicional de 7 Dias"
        ]}
        buttonText="QUERO O KIT ESSENCIAL"
      />

      <OfferCard 
        isPremium
        highlight="MAIS VENDIDO"
        title="Kit Premium Completo"
        price="27,00"
        originalPrice="341,00"
        checkoutUrl="https://checkout.salmoscomentados.online/VCCL1O8SCOW5"
        features={[
          "Tudo do pacote Kit Essencial",
          "BÔNUS 1: 300 Planos Inclusivos (TDAH, TEA e mais)",
          "BÔNUS 2: 500 Atividades Extras para Imprimir",
          "Acesso Vitalício Garantido"
        ]}
        buttonText="QUERO O KIT PREMIUM"
        subText="+ 500 pessoas escolheram essa oferta"
      />
    </div>
  );
}