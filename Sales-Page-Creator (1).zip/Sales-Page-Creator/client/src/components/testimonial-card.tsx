import { Star } from "lucide-react";

interface TestimonialCardProps {
  name: string;
  role: string;
  content: string;
  avatarInitial: string;
}

export function TestimonialCard({ name, role, content, avatarInitial }: TestimonialCardProps) {
  return (
    <div className="bg-white p-8 rounded-3xl shadow-xl shadow-black/5 border border-primary/10 relative">
      <div className="absolute -top-6 left-8 bg-secondary text-white w-12 h-12 rounded-xl flex items-center justify-center text-3xl font-serif leading-none shadow-lg shadow-secondary/20">
        "
      </div>
      
      <div className="flex gap-1 mb-4 pt-2">
        {[1, 2, 3, 4, 5].map((i) => (
          <Star key={i} className="w-4 h-4 fill-amber-400 text-amber-400" />
        ))}
      </div>
      
      <p className="text-foreground/80 italic mb-6 leading-relaxed">
        {content}
      </p>
      
      <div className="flex items-center gap-4">
        <div className="w-12 h-12 rounded-full bg-primary/10 text-primary font-bold flex items-center justify-center text-lg border-2 border-primary/20">
          {avatarInitial}
        </div>
        <div>
          <h4 className="font-bold text-foreground text-sm">{name}</h4>
          <p className="text-xs text-muted-foreground font-medium">{role}</p>
        </div>
      </div>
    </div>
  );
}
